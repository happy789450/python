from distutils.core import setup
# name 模块名称
# version 版本号
# description 描述
# author 作者
# py_modules 要发布的内容
setup(name="mokuai",version="1.0",description="my module",author="rice",
py_modules=['mokuai'])